These are the scripts from VTS 3.5.3.
They have been replaced in the main script directory with cleaned up scripts
from SourceForge/vts messages 1704394 and 1704507, which will we further
generalized over time.  If you prefer the old scripts, they are available
here, or from CVS.
