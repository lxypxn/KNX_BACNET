The scripts in this folder are intended primarily to help with debugging and 
regression testing of the BAcnet detail decoder.

Parts may be useful as a starting place for other tests.

Destination address and DeviceID are set in config.vts
